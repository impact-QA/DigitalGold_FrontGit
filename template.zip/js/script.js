function openNav() {
    
    document.getElementById("mysidenav_resp_dd").style.width = "250px";
    document.getElementById("bodyMainID").style.position = "relative";
    document.getElementById("bodyMainID").style.left = "250px";
}



function closeNav() {
    document.getElementById("mysidenav_resp_dd").style.width = "0";
    document.getElementById("bodyMainID").style.left = "0";
}

